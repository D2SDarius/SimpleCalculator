import time
num1 = float(input("enter the first number:"))
op = input("Enter Operator:")
num2 = float(input("enter the second number:"))

file = open("Result.txt", "w")

if op == "+":
    print(num1 + num2)
    result = num1 + num2
    file.write(str(result))
    time.sleep(4)
elif op == "-":
    print(num1 - num2)
    result = num1 - num2
    file.write(str(result))
    time.sleep(4)
elif op == "*":
    print(num1 * num2)
    result = num1 * num2
    file.write(str(result))
    time.sleep(4)
elif op == "/":
    print(num1 / num2)
    result = num1 / num2
    file.write(str(result))
    time.sleep(4)
else:
    print("invalid operator")
    result = "INVALID OPERATOR"
    file.write(str(result))
    time.sleep(4)
